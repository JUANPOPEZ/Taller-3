@echo off
title Traductor ASCII - Ejecutable de Escritorio
echo ========================================================
echo Iniciando Traductor ASCII...
echo ========================================================
python app.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Ocurrio un error al ejecutar la aplicacion.
    echo Verifica que tengas Python instalado y en tu PATH.
    pause
)
