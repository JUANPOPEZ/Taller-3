# GUION PARA VIDEO EXPLICATIVO (DURACIÓN: MÁXIMO 5 MINUTOS)

> **Instrucciones de grabación:**  
> Puedes grabar tu pantalla usando OBS Studio, PowerPoint (Grabación de pantalla) o la grabadora de pantalla de tu celular Android. Mantén un tono claro, seguro y pausado.

---

### [0:00 - 0:45] Bloque 1: Introducción y Portada del Proyecto
* **En pantalla:** Portada con el título "Proyecto Traductor ASCII", nombres de los integrantes, asignatura y fecha. Luego mostrar el boceto original del cuaderno comparado lado a lado con la aplicación real.
* **Locución (Voz):**
  > *"Cordial saludo, profesor y compañeros. En este video presentamos el proyecto **Traductor ASCII**, desarrollado para permitir la selección y conversión interactiva de texto en representaciones visuales mediante arte ASCII alfanumérico.*
  > 
  > *Como pueden observar en la pantalla, partimos de este boceto a mano alzada donde se definieron los requerimientos de la interfaz gráfica: título central, caja de ingreso de texto, selector de caracteres con tres estilos distintos, botones de acción para generar, limpiar y copiar, y un área de visualización monoespaciada para el resultado.*
  > 
  > *A continuación, demostraremos su funcionamiento tanto en la versión móvil como en el código fuente en Python."*

---

### [0:45 - 2:00] Bloque 2: Demostración en Vivo de la Aplicación Móvil (APK)
* **En pantalla:** La aplicación ejecutándose en el celular Android (o en el preview interactivo).
* **Locución (Voz):**
  > *(Tocar el botón "Generar" sin escribir nada)*
  > *"Comencemos validando los controles de seguridad: si intentamos generar el arte con el campo vacío, el sistema detecta la ausencia de datos y nos muestra una alerta inmediata impidiendo errores de ejecución.*
  > 
  > *(Escribir la palabra 'HOLA' y dejar seleccionado el estilo 'Estándar')*
  > *Ahora ingresamos la palabra 'HOLA' con el estilo por defecto: Estándar clásico con caracteres de almohadilla. Al presionar 'Generar Arte ASCII', observamos en el área inferior cómo cada letra se construye mediante una matriz de 5 filas de altura, perfectamente alineada.*
  > 
  > *(Seleccionar 'Bloques sólidos' y presionar 'Generar')*
  > *Si cambiamos al modo 'Bloques sólidos', la misma palabra se renderiza utilizando caracteres Unicode de alta densidad, simulando un rótulo sólido.*
  > 
  > *(Seleccionar 'Matriz / Binario' y presionar 'Generar')*
  > *Finalmente, en el modo 'Matriz / Binario', obtenemos una representación digital en ceros y unos al estilo consola de comandos.*
  > 
  > *(Presionar 'Copiar resultado' y luego 'Limpiar')*
  > *Con el botón 'Copiar resultado', el texto se envía directamente al portapapeles del celular, listo para compartirse en cualquier red social o editor de texto. Y con el botón 'Limpiar', restablecemos la aplicación a su estado inicial."*

---

### [2:00 - 3:30] Bloque 3: Arquitectura y Explicación del Código en Python
* **En pantalla:** Visual Studio Code o editor de texto mostrando el archivo `app.py`.
* **Locución (Voz):**
  > *"Para garantizar la máxima legibilidad y facilidad de sustentación, la arquitectura de la aplicación en Python se diseñó en cuatro secciones modulares:*
  > 
  > *1. **Sección de Matrices (`MATRICES_CARACTERES`):** Cada letra y número está modelado como una lista de 5 renglones donde el número '1' representa el trazo de la letra y el '0' el espacio vacío.*
  > 
  > *2. **Sección de Transformación (`convertir_texto_a_ascii`):** Esta función toma la palabra, la pasa a mayúsculas con `.upper()` y recorre letra por letra, concatenando horizontalmente las 5 filas correspondientes según el estilo de carácter seleccionado.*
  > 
  > *3. **Sección de Controladores:** Funciones sencillas e independientes: `accion_generar()` que valida el campo vacío con `messagebox.showwarning()`, `accion_limpiar()` que borra los datos, y `accion_copiar()` que interactúa con el `clipboard`.*
  > 
  > *4. **Sección de Interfaz Gráfica (`Tkinter`):** Construida con empaquetamiento directo mediante `.pack()`. Esto nos permite modificar la posición de cualquier botón o elemento en segundos simplemente cambiando el orden de las instrucciones."*

---

### [3:30 - 4:15] Bloque 4: Flexibilidad de la Interfaz y Pruebas
* **En pantalla:** Demostración rápida de cambio de color o posición en el código (ej. cambiar el color de un botón en el diccionario `COLORES` y volver a ejecutar).
* **Locución (Voz):**
  > *"Una de las principales ventajas de esta estructura es su adaptabilidad. Por ejemplo, todos los colores de la aplicación están centralizados en un diccionario superior. Si se nos solicita cambiar el color del botón generar o modificar la disposición de los botones secundarios, basta con ajustar una sola línea sin comprometer la lógica del algoritmo matricial.*
  > 
  > *Adicionalmente, se generó el paquete ejecutable `TraductorASCII.apk` firmado y optimizado con las herramientas nativas del Android SDK, garantizando una ejecución ligera, veloz y 100% desconectada de internet."*

---

### [4:15 - 4:45] Bloque 5: Conclusiones y Cierre
* **En pantalla:** Pantalla final con agradecimientos y resumen de entregables (Código fuente, APK ejecutable, Documento técnico y Video).
* **Locución (Voz):**
  > *"En conclusión, el proyecto cumple a cabalidad con todos los requisitos funcionales y de diseño planteados en la guía: fidelidad al boceto, robustez en la validación, múltiples estilos de salida y una arquitectura de código simple y elegante.*
  > 
  > *Muchas gracias por su atención y quedamos atentos a cualquier pregunta."*
