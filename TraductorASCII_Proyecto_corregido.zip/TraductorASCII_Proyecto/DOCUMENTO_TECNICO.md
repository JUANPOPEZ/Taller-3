# DOCUMENTO TÉCNICO: TRADUCTOR ASCII

---

## 1. Portada y Ficha Técnica
* **Nombre de la Aplicación:** TRADUCTOR ASCII
* **Versión:** 1.0.0
* **Lenguaje Principal:** Python 3.x (Tkinter / Pydroid 3)
* **Plataforma Móvil:** Android (Paquete `.apk` nativo compilado con Android SDK)
* **Compatibilidad:** Android 5.0 Lollipop en adelante (API 21+) y Windows/macOS/Linux
* **Fecha:** Noviembre 2026

---

## 2. Descripción del Problema y Objetivos
### 2.1 Planteamiento
El proyecto surge de la necesidad didáctica de representar caracteres alfanuméricos tradicionales en patrones visuales matriciales (Arte ASCII), permitiendo al usuario seleccionar letras o palabras y observar su conversión gráfica inmediata en diferentes estilos:
1. **Estándar:** Símbolos clásicos de tipografía (`#`, `*`, `:`).
2. **Bloques sólidos:** Glifos Unicode de alta densidad (`█`, `▓`).
3. **Matriz / Binario:** Representación digital de unos y ceros (`1`, `0`).

### 2.2 Objetivos del Sistema
* Proporcionar una interfaz gráfica táctil intuitiva basada en el boceto aprobado.
* Implementar validaciones que alerten sobre entradas vacías o caracteres no soportados.
* Ofrecer herramientas de productividad integradas: generación con tecla Enter, botón de limpieza rápida y exportación al portapapeles del dispositivo.
* Garantizar portabilidad plena en smartphones Android mediante un instalador APK sin dependencias externas.

---

## 3. Arquitectura del Software

```mermaid
flowchart TD
    A["Usuario ingresa texto"] --> B["Selecciona estilo gráfico"]
    B --> C{"¿Presiona 'Generar'?"}
    C -->|No| D["Espera interacción"]
    C -->|Sí| E{"¿Texto vacío?"}
    E -->|Sí| F["Muestra Alerta / Toast: 'Campo Vacío'"]
    E -->|No| G["Limpieza de entrada (Upper / Strip)"]
    G --> H["Búsqueda en Matriz 5x5"]
    H --> I["Sustitución de 1 y 0 según estilo"]
    I --> J["Concatenación horizontal de 5 líneas"]
    J --> K["Render en Área Monospace (Resultado)"]
    K --> L{"¿Copiar al Portapapeles?"}
    L -->|Sí| M["Copia al Clipboard del Dispositivo"]
```

### 3.1 Módulos del Sistema
1. **Módulo de Definición Matricial (`MATRICES_CARACTERES`):**  
   Almacena un diccionario asociativo donde cada llave es una letra (A-Z) o número (0-9) y su valor es un arreglo de 5 cadenas de longitud 5 representando la forma del glifo.
2. **Módulo de Transformación (`convertir_texto_a_ascii`):**  
   Recorre la cadena ingresada letra por letra, extrae la fila correspondiente del carácter y mapea los bits activos a los caracteres elegidos por el usuario (`#`, `█`, o `1`).
3. **Módulo de Interfaz de Usuario (UI / Layout):**  
   Distribución vertical con márgenes estandarizados idéntica al boceto a mano alzada.
4. **Módulo de Integración Android (`WebAppInterface` & Bridge):**  
   Permite al motor web interno invocar servicios nativos de Android como el `ClipboardManager` y los avisos emergentes `Toast`.

---

## 4. Pruebas y Validación (Matriz de Evidencias)

| Caso de Prueba | Entrada de Prueba | Acción / Botón | Resultado Esperado | Resultado Obtenido | Estado |
|---|---|---|---|---|---|
| **CP-01: Campo Vacío** | Cadena vacía `""` | Clic en *Generar Arte ASCII* | Mensaje de advertencia pidiendo texto | Alerta emergente indicando "Por favor ingresa texto" | **APROBADO** |
| **CP-02: Conversión Estándar** | `"HOLA"` | Selector: *Estándar (#)* -> *Generar* | Arte ASCII formado con almohadillas `#` en 5 líneas | Renderizado simétrico de "HOLA" con `#` | **APROBADO** |
| **CP-03: Bloques Sólidos** | `"SOL"` | Selector: *Bloques (█)* -> *Generar* | Arte ASCII denso con caracteres `█` | Visualización en bloques sólidos continuos | **APROBADO** |
| **CP-04: Matriz Binaria** | `"123"` | Selector: *Binario (1 0)* -> *Generar* | Letras formadas por secuencias de `1` y fondo `0` | Matriz binaria tipo terminal | **APROBADO** |
| **CP-05: Botón Limpiar** | Texto en caja y resultado generado | Clic en *Limpiar* | Entrada vacía, selector en Estándar, resultado reseteado | Todo el formulario queda en estado inicial | **APROBADO** |
| **CP-06: Portapapeles** | Arte generado en pantalla | Clic en *Copiar* | Texto copiado al portapapeles del sistema | Mensaje "¡Copiado!" y contenido listo para pegar | **APROBADO** |
| **CP-07: Instalación APK** | Archivo `TraductorASCII.apk` | Instalar y abrir en Android | Apertura instantánea sin cierres forzados | Ejecución fluida offline sin crasheos | **APROBADO** |

---

## 5. Manual de Instalación y Ejecución

### 5.1 En Celular Android (APK Directo)
1. Conecta el celular a la computadora mediante cable USB o comparte el archivo `TraductorASCII.apk` por WhatsApp / Google Drive / Bluetooth.
2. En el celular, abre el archivo descargado. Si solicita permiso de "Instalar aplicaciones de fuentes desconocidas", habilítalo.
3. Toca **Instalar** y luego **Abrir**. La aplicación funcionará sin necesidad de internet.

### 5.2 En Computadora (Python de Escritorio)
1. Asegúrate de tener Python instalado.
2. Abre la carpeta del proyecto y haz doble clic sobre el archivo `run_desktop.bat` (o escribe `python app.py` en la terminal).

### 5.3 En Celular mediante Pydroid 3 (Opcional)
1. Descarga **Pydroid 3** desde Google Play Store.
2. Abre el archivo `app.py` dentro de Pydroid y presiona el botón amarillo de **Play**.
