"""
=============================================================================
PROYECTO: TRADUCTOR ASCII
DESCRIPCIÓN: Aplicación que convierte texto ingresado por el usuario en 
             arte ASCII visual mediante matrices de caracteres.
LENGUAJE: Python 3 con interfaz Tkinter (estándar, sin librerías externas).
=============================================================================
GUÍA RÁPIDA PARA SUSTENTAR ANTE EL PROFESOR:
- Si el profesor pide cambiar posiciones de botones: busca la sección "SECCIÓN 4"
  y modifica los valores de 'row' (fila) y 'column' (columna) o 'pady'/'padx'.
- Si pide cambiar los caracteres de arte: busca "SECCIÓN 1" y "SECCIÓN 2".
- Si pide cambiar los colores: busca el diccionario "COLORES" abajo.
=============================================================================
"""

import tkinter as tk
from tkinter import ttk, messagebox

# =============================================================================
# CONFIGURACIÓN VISUAL Y COLORES (Fácil de modificar si el profesor lo pide)
# =============================================================================
COLORES = {
    "fondo_ventana": "#F4F6F9",      # Fondo general claro
    "tarjeta": "#FFFFFF",            # Fondo del contenedor central
    "borde": "#2C3E50",              # Color de bordes (azul oscuro / pizarra)
    "texto_titulo": "#1A252F",       # Color del título principal
    "texto_etiqueta": "#34495E",     # Color de textos secundarios
    "boton_generar": "#2980B9",      # Azul para generar
    "boton_limpiar": "#E74C3C",      # Rojo suave para limpiar
    "boton_copiar": "#27AE60",       # Verde para copiar
    "pantalla_resultado": "#1E272E", # Fondo oscuro estilo terminal
    "texto_resultado": "#00FF66"     # Letras verdes fosforescentes (Matrix)
}

# =============================================================================
# SECCIÓN 1: MATRICES 5x5 DE CADA CARÁCTER
# Cada letra/número está definido por una matriz de 5 filas de 0 y 1.
# 1 = Pixel encendido (figura)
# 0 = Pixel apagado (espacio vacío)
# =============================================================================
MATRICES_CARACTERES = {
    'A': [
        " 111 ",
        "1   1",
        "11111",
        "1   1",
        "1   1"
    ],
    'B': [
        "1111 ",
        "1   1",
        "1111 ",
        "1   1",
        "1111 "
    ],
    'C': [
        " 1111",
        "1    ",
        "1    ",
        "1    ",
        " 1111"
    ],
    'D': [
        "1111 ",
        "1   1",
        "1   1",
        "1   1",
        "1111 "
    ],
    'E': [
        "11111",
        "1    ",
        "1111 ",
        "1    ",
        "11111"
    ],
    'F': [
        "11111",
        "1    ",
        "1111 ",
        "1    ",
        "1    "
    ],
    'G': [
        " 1111",
        "1    ",
        "1  11",
        "1   1",
        " 1111"
    ],
    'H': [
        "1   1",
        "1   1",
        "11111",
        "1   1",
        "1   1"
    ],
    'I': [
        "11111",
        "  1  ",
        "  1  ",
        "  1  ",
        "11111"
    ],
    'J': [
        "  111",
        "    1",
        "    1",
        "1   1",
        " 111 "
    ],
    'K': [
        "1   1",
        "1  1 ",
        "111  ",
        "1  1 ",
        "1   1"
    ],
    'L': [
        "1    ",
        "1    ",
        "1    ",
        "1    ",
        "11111"
    ],
    'M': [
        "1   1",
        "11 11",
        "1 1 1",
        "1   1",
        "1   1"
    ],
    'N': [
        "1   1",
        "11  1",
        "1 1 1",
        "1  11",
        "1   1"
    ],
    'O': [
        " 111 ",
        "1   1",
        "1   1",
        "1   1",
        " 111 "
    ],
    'P': [
        "1111 ",
        "1   1",
        "1111 ",
        "1    ",
        "1    "
    ],
    'Q': [
        " 111 ",
        "1   1",
        "1 1 1",
        "1  1 ",
        " 11 1"
    ],
    'R': [
        "1111 ",
        "1   1",
        "1111 ",
        "1  1 ",
        "1   1"
    ],
    'S': [
        " 1111",
        "1    ",
        " 111 ",
        "    1",
        "1111 "
    ],
    'T': [
        "11111",
        "  1  ",
        "  1  ",
        "  1  ",
        "  1  "
    ],
    'U': [
        "1   1",
        "1   1",
        "1   1",
        "1   1",
        " 111 "
    ],
    'V': [
        "1   1",
        "1   1",
        "1   1",
        " 1 1 ",
        "  1  "
    ],
    'W': [
        "1   1",
        "1   1",
        "1 1 1",
        "11 11",
        "1   1"
    ],
    'X': [
        "1   1",
        " 1 1 ",
        "  1  ",
        " 1 1 ",
        "1   1"
    ],
    'Y': [
        "1   1",
        " 1 1 ",
        "  1  ",
        "  1  ",
        "  1  "
    ],
    'Z': [
        "11111",
        "   1 ",
        "  1  ",
        " 1   ",
        "11111"
    ],
    '0': [
        " 111 ",
        "1  11",
        "1 1 1",
        "11  1",
        " 111 "
    ],
    '1': [
        "  11 ",
        " 1 1 ",
        "   1 ",
        "   1 ",
        " 1111"
    ],
    '2': [
        " 111 ",
        "1   1",
        "   1 ",
        " 1   ",
        "11111"
    ],
    '3': [
        "1111 ",
        "    1",
        "  11 ",
        "    1",
        "1111 "
    ],
    '4': [
        "1  1 ",
        "1  1 ",
        "11111",
        "   1 ",
        "   1 "
    ],
    '5': [
        "11111",
        "1    ",
        "1111 ",
        "    1",
        "1111 "
    ],
    '6': [
        " 111 ",
        "1    ",
        "1111 ",
        "1   1",
        " 111 "
    ],
    '7': [
        "11111",
        "    1",
        "   1 ",
        "  1  ",
        "  1  "
    ],
    '8': [
        " 111 ",
        "1   1",
        " 111 ",
        "1   1",
        " 111 "
    ],
    '9': [
        " 111 ",
        "1   1",
        " 1111",
        "    1",
        " 111 "
    ],
    ' ': [
        "     ",
        "     ",
        "     ",
        "     ",
        "     "
    ],
    '?': [
        " 111 ",
        "1   1",
        "  11 ",
        "     ",
        "  1  "
    ],
    '!': [
        "  1  ",
        "  1  ",
        "  1  ",
        "     ",
        "  1  "
    ]
}

# =============================================================================
# SECCIÓN 1.1: MATRICES 5x5 DE LAS LETRAS MINÚSCULAS
# Las minúsculas "bajas" (a, c, e, m, n, o...) usan solo las filas 2 a 5 y dejan
# la fila 1 vacía; las altas (b, d, f, h, k, l, t) ocupan las 5 filas.
# Así "Juan" se distingue visualmente de "JUAN".
# =============================================================================
MATRICES_MINUSCULAS = {
    'a': ["     ", " 111 ", "    1", " 1111", "1  11"],
    'b': ["1    ", "1    ", "1111 ", "1   1", "1111 "],
    'c': ["     ", " 111 ", "1    ", "1    ", " 111 "],
    'd': ["    1", "    1", " 1111", "1   1", " 1111"],
    'e': ["     ", " 111 ", "11111", "1    ", " 111 "],
    'f': ["  11 ", " 1   ", "1111 ", " 1   ", " 1   "],
    'g': [" 1111", "1   1", " 1111", "    1", " 111 "],
    'h': ["1    ", "1    ", "1111 ", "1   1", "1   1"],
    'i': ["  1  ", "     ", "  1  ", "  1  ", "  1  "],
    'j': ["   1 ", "     ", "   1 ", "1  1 ", " 11  "],
    'k': ["1    ", "1  1 ", "111  ", "1  1 ", "1   1"],
    'l': [" 11  ", "  1  ", "  1  ", "  1  ", "  11 "],
    'm': ["     ", "11 1 ", "1 1 1", "1 1 1", "1 1 1"],
    'n': ["     ", "1111 ", "1   1", "1   1", "1   1"],
    'o': ["     ", " 111 ", "1   1", "1   1", " 111 "],
    'p': ["     ", "1111 ", "1   1", "1111 ", "1    "],
    'q': ["     ", " 1111", "1   1", " 1111", "    1"],
    'r': ["     ", "1 11 ", "11  1", "1    ", "1    "],
    's': ["     ", " 1111", "1    ", " 111 ", "1111 "],
    't': [" 1   ", "1111 ", " 1   ", " 1   ", "  11 "],
    'u': ["     ", "1   1", "1   1", "1  11", " 11 1"],
    'v': ["     ", "1   1", "1   1", " 1 1 ", "  1  "],
    'w': ["     ", "1   1", "1 1 1", "1 1 1", " 1 1 "],
    'x': ["     ", "1   1", " 1 1 ", " 1 1 ", "1   1"],
    'y': ["     ", "1   1", " 1 1 ", "  1  ", " 1   "],
    'z': ["     ", "11111", "  1  ", " 1   ", "11111"]
}

# Unimos las minúsculas al diccionario principal para que la búsqueda
# MATRICES_CARACTERES.get(letra) encuentre mayúsculas y minúsculas.
MATRICES_CARACTERES.update(MATRICES_MINUSCULAS)

# =============================================================================
# SECCIÓN 2: LÓGICA DE CONVERSIÓN Y ESTILOS
# Define los símbolos con los que se reemplaza el 1 (relleno) y el 0 (fondo).
# =============================================================================
ESTILOS = {
    "Estandar": {
        "nombre": "Estándar (Clásico / # * : )",
        "caracter_relleno": "#",
        "caracter_vacio": " "
    },
    "Bloques": {
        "nombre": "Bloques sólidos (█ ▓)",
        "caracter_relleno": "█",
        "caracter_vacio": " "
    },
    "Binario": {
        "nombre": "Matriz / Binario (1 0 1 0)",
        "caracter_relleno": "1",
        "caracter_vacio": "0"
    }
}

def convertir_texto_a_ascii(texto_usuario, clave_estilo):
    """
    Toma una cadena de texto y devuelve el arte ASCII en 5 líneas de alto.
    """
    estilo = ESTILOS.get(clave_estilo, ESTILOS["Estandar"])
    relleno = estilo["caracter_relleno"]
    vacio = estilo["caracter_vacio"]

    # Se respeta mayúsculas y minúsculas tal como las escribió el usuario
    texto_limpio = texto_usuario.strip()
    if not texto_limpio:
        return ""

    # Inicializamos 5 renglones vacíos
    lineas_resultado = ["", "", "", "", ""]

    # Recorremos cada letra de la palabra ingresada
    for letra in texto_limpio:
        # Si la letra existe en la matriz la usamos, sino usamos '?'
        matriz = MATRICES_CARACTERES.get(letra, MATRICES_CARACTERES['?'])
        
        # Agregamos cada fila de la matriz a su renglón correspondiente
        for fila_idx in range(5):
            fila_original = matriz[fila_idx]
            # Convertimos 1 en relleno y 0/espacio en vacío
            fila_traducida = ""
            for pixel in fila_original:
                if pixel == '1':
                    fila_traducida += relleno
                else:
                    fila_traducida += vacio
            
            # Dejamos 2 espacios de separación entre cada letra
            lineas_resultado[fila_idx] += fila_traducida + "  "

    # Unimos las 5 líneas con saltos de línea
    return "\n".join(lineas_resultado)


# =============================================================================
# SECCIÓN 3: CONTROLADORES / FUNCIONES DE LOS BOTONES
# =============================================================================
def accion_generar():
    """Botón 'Generar Arte ASCII': valida entrada y muestra el resultado."""
    texto = entrada_texto.get().strip()

    # Validación de campo vacío (requerimiento explícito)
    if not texto:
        messagebox.showwarning(
            "Campo Vacío", 
            "¡Por favor ingresa al menos una letra o palabra para traducir!"
        )
        entrada_texto.focus()
        return

    estilo_seleccionado = variable_estilo.get()
    resultado_ascii = convertir_texto_a_ascii(texto, estilo_seleccionado)

    # Mostramos el resultado en el área de texto
    area_resultado.config(state="normal")      # Habilitar edición temporal
    area_resultado.delete("1.0", tk.END)       # Borrar texto previo
    area_resultado.insert(tk.END, resultado_ascii) # Escribir nuevo arte
    area_resultado.config(state="disabled")    # Bloquear para que sea de solo lectura

def accion_limpiar():
    """Botón 'Limpiar': borra la caja de entrada y la pantalla de resultado."""
    entrada_texto.delete(0, tk.END)
    area_resultado.config(state="normal")
    area_resultado.delete("1.0", tk.END)
    area_resultado.config(state="disabled")
    variable_estilo.set("Estandar")
    entrada_texto.focus()

def accion_copiar():
    """Botón 'Copiar resultado': copia el arte ASCII al portapapeles."""
    area_resultado.config(state="normal")
    contenido = area_resultado.get("1.0", tk.END).strip()
    area_resultado.config(state="disabled")

    if not contenido:
        messagebox.showinfo("Copiar", "No hay resultado para copiar. Genera uno primero.")
        return

    # Limpiar portapapeles y pegar contenido
    ventana.clipboard_clear()
    ventana.clipboard_append(contenido)
    messagebox.showinfo("Éxito", "¡Arte ASCII copiado al portapapeles con éxito!")


# =============================================================================
# SECCIÓN 4: CONSTRUCCIÓN DE LA INTERFAZ GRÁFICA (EXACTA AL BOCETO)
# Nota para sustentación: Aquí puedes cambiar de orden los widgets o sus estilos
# =============================================================================
ventana = tk.Tk()
ventana.title("TRADUCTOR ASCII")
ventana.geometry("450x640")
ventana.configure(bg=COLORES["fondo_ventana"])
ventana.resizable(True, True)

# Contenedor central tipo teléfono / tarjeta
marco_principal = tk.Frame(
    ventana, 
    bg=COLORES["tarjeta"], 
    bd=2, 
    relief="groove", 
    padx=20, 
    pady=15
)
marco_principal.pack(padx=15, pady=15, fill="both", expand=True)

# 1. TÍTULO PRINCIPAL ("TRADUCTOR ASCII" como en el dibujo)
etiqueta_titulo = tk.Label(
    marco_principal,
    text="TRADUCTOR ASCII",
    font=("Arial", 18, "bold"),
    bg=COLORES["tarjeta"],
    fg=COLORES["texto_titulo"]
)
etiqueta_titulo.pack(pady=(5, 12))

# 2. SECCIÓN: INGRESO DE TEXTO
etiqueta_ingreso = tk.Label(
    marco_principal,
    text="Ingreso de texto",
    font=("Arial", 12, "bold"),
    bg=COLORES["tarjeta"],
    fg=COLORES["texto_etiqueta"],
    anchor="w"
)
etiqueta_ingreso.pack(fill="x", pady=(4, 2))

# Campo de texto (Entry)
entrada_texto = tk.Entry(
    marco_principal,
    font=("Arial", 13),
    bd=2,
    relief="solid",
    justify="center"
)
entrada_texto.pack(fill="x", ipady=6, pady=(0, 12))
entrada_texto.focus() # Coloca el cursor directamente aquí

# 3. SECCIÓN: SELECTOR DE CARACTERES (Opciones idénticas a la imagen)
etiqueta_selector = tk.Label(
    marco_principal,
    text="Selector de caracteres",
    font=("Arial", 12, "bold"),
    bg=COLORES["tarjeta"],
    fg=COLORES["texto_etiqueta"],
    anchor="w"
)
etiqueta_selector.pack(fill="x", pady=(4, 2))

# Marco con borde punteado/groove que encierra las opciones
marco_selector = tk.LabelFrame(
    marco_principal,
    text=" Estilos Disponibles ",
    font=("Arial", 9, "italic"),
    bg=COLORES["tarjeta"],
    bd=1,
    relief="groove",
    padx=10,
    pady=6
)
marco_selector.pack(fill="x", pady=(0, 12))

variable_estilo = tk.StringVar(value="Estandar")

# RadioButtons de las 3 opciones exactas del dibujo
radio_1 = tk.Radiobutton(
    marco_selector,
    text="Estándar (Clásico / # * : )",
    variable=variable_estilo,
    value="Estandar",
    font=("Arial", 10),
    bg=COLORES["tarjeta"],
    activebackground=COLORES["tarjeta"],
    anchor="w"
)
radio_1.pack(fill="x", pady=2)

radio_2 = tk.Radiobutton(
    marco_selector,
    text="Bloques sólidos (█ ▓)",
    variable=variable_estilo,
    value="Bloques",
    font=("Arial", 10),
    bg=COLORES["tarjeta"],
    activebackground=COLORES["tarjeta"],
    anchor="w"
)
radio_2.pack(fill="x", pady=2)

radio_3 = tk.Radiobutton(
    marco_selector,
    text="Matriz / Binario (1 0 1 0)",
    variable=variable_estilo,
    value="Binario",
    font=("Arial", 10),
    bg=COLORES["tarjeta"],
    activebackground=COLORES["tarjeta"],
    anchor="w"
)
radio_3.pack(fill="x", pady=2)

# 4. BOTONES DE ACCIÓN: Generar, Limpiar, Copiar
# Botón principal grande "Generar Arte ASCII"
boton_generar = tk.Button(
    marco_principal,
    text="Generar Arte ASCII",
    font=("Arial", 12, "bold"),
    bg=COLORES["boton_generar"],
    fg="white",
    bd=2,
    relief="raised",
    cursor="hand2",
    command=accion_generar
)
boton_generar.pack(fill="x", ipady=4, pady=(2, 6))

# Marco secundario horizontal para los botones "Limpiar" y "Copiar resultado"
marco_botones_secundarios = tk.Frame(marco_principal, bg=COLORES["tarjeta"])
marco_botones_secundarios.pack(fill="x", pady=(0, 10))

boton_copiar = tk.Button(
    marco_botones_secundarios,
    text="📋 Copiar",
    font=("Arial", 10, "bold"),
    bg=COLORES["boton_copiar"],
    fg="white",
    relief="groove",
    cursor="hand2",
    command=accion_copiar
)
boton_copiar.pack(side="left", expand=True, fill="x", padx=(0, 4), ipady=3)

boton_limpiar = tk.Button(
    marco_botones_secundarios,
    text="🗑 Limpiar",
    font=("Arial", 10, "bold"),
    bg=COLORES["boton_limpiar"],
    fg="white",
    relief="groove",
    cursor="hand2",
    command=accion_limpiar
)
boton_limpiar.pack(side="right", expand=True, fill="x", padx=(4, 0), ipady=3)

# 5. SECCIÓN DE RESULTADO ("Resultado ->" exactamente como en la imagen)
etiqueta_resultado = tk.Label(
    marco_principal,
    text="Resultado ➔",
    font=("Arial", 12, "bold"),
    bg=COLORES["tarjeta"],
    fg=COLORES["texto_etiqueta"],
    anchor="w"
)
etiqueta_resultado.pack(fill="x", pady=(2, 4))

# Área de texto con tipografía monoespaciada (Courier / Consolas) para alineación perfecta
area_resultado = tk.Text(
    marco_principal,
    font=("Consolas", 10, "bold"), # Monoespaciado obligatorio para arte ASCII
    bg=COLORES["pantalla_resultado"],
    fg=COLORES["texto_resultado"],
    bd=2,
    relief="sunken",
    height=8,
    wrap="none" # wrap="none" para no romper el arte horizontal
)
area_resultado.pack(fill="both", expand=True, pady=(0, 4))

# Barra de desplazamiento horizontal por si la palabra es larga
barra_horizontal = tk.Scrollbar(
    marco_principal, 
    orient="horizontal", 
    command=area_resultado.xview
)
barra_horizontal.pack(fill="x", pady=(0, 2))
area_resultado.configure(xscrollcommand=barra_horizontal.set)

# Estado inicial
area_resultado.insert(tk.END, "  [ Tu arte ASCII aparecerá aquí ]")
area_resultado.config(state="disabled")

# Permitir generar presionando la tecla ENTER en el campo de texto
entrada_texto.bind("<Return>", lambda event: accion_generar())

# =============================================================================
# EJECUCIÓN PRINCIPAL DEL BUCLE
# =============================================================================
if __name__ == "__main__":
    ventana.mainloop()
