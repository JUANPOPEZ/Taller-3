$ErrorActionPreference = "Stop"

$sdkPath = "C:\Users\juanl\AppData\Local\Android\Sdk"
$buildToolsPath = "$sdkPath\build-tools\36.0.0"
$platformPath = "$sdkPath\platforms\android-37.0"
$androidJar = "$platformPath\android.jar"
$workDir = "C:\Users\juanl\.gemini\antigravity\scratch\traductor_ascii\android_build"
$outputApk = "C:\Users\juanl\.gemini\antigravity\scratch\traductor_ascii\TraductorASCII.apk"

Set-Location $workDir

Write-Host ">>> 1. Limpiando y creando carpetas de compilación..." -ForegroundColor Cyan
if (Test-Path "build") { Remove-Item -Recurse -Force "build" }
New-Item -ItemType Directory -Force -Path "build\compiled_res" | Out-Null
New-Item -ItemType Directory -Force -Path "build\gen" | Out-Null
New-Item -ItemType Directory -Force -Path "build\classes" | Out-Null
New-Item -ItemType Directory -Force -Path "build\dex" | Out-Null

Write-Host ">>> 2. Generando clave debug si no existe..." -ForegroundColor Cyan
if (-not (Test-Path "debug.keystore")) {
    & keytool -genkeypair -v -keystore "debug.keystore" -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US"
}

Write-Host ">>> 3. Compilando recursos con aapt2..." -ForegroundColor Cyan
& "$buildToolsPath\aapt2.exe" compile --dir "res" -o "build\compiled_res.zip"

Write-Host ">>> 4. Enlazando recursos y generando R.java..." -ForegroundColor Cyan
& "$buildToolsPath\aapt2.exe" link -I "$androidJar" --manifest "AndroidManifest.xml" -o "build\unaligned.apk" "build\compiled_res.zip" -A "assets" --java "build\gen"

Write-Host ">>> 5. Compilando clases Java con javac..." -ForegroundColor Cyan
$javaFiles = (Get-ChildItem -Path "src", "build\gen" -Recurse -Filter "*.java").FullName
& javac --release 11 -cp "$androidJar;build\gen" -d "build\classes" $javaFiles

Write-Host ">>> 6. Convirtiendo bytecode a DEX con d8..." -ForegroundColor Cyan
$classFiles = (Get-ChildItem -Path "build\classes" -Recurse -Filter "*.class").FullName
& "$buildToolsPath\d8.bat" --min-api 21 --lib "$androidJar" --output "build\dex" $classFiles

Write-Host ">>> 7. Insertando classes.dex dentro del APK..." -ForegroundColor Cyan
Set-Location "build\dex"
& jar uf "..\unaligned.apk" "classes.dex"
Set-Location $workDir

Write-Host ">>> 8. Alineando APK con zipalign (4 bytes)..." -ForegroundColor Cyan
& "$buildToolsPath\zipalign.exe" -f -p 4 "build\unaligned.apk" "build\aligned.apk"

Write-Host ">>> 9. Firmando el APK con apksigner..." -ForegroundColor Cyan
& "$buildToolsPath\apksigner.bat" sign --ks "debug.keystore" --ks-pass "pass:android" --key-pass "pass:android" --ks-key-alias "androiddebugkey" "build\aligned.apk"

Write-Host ">>> 10. Verificando firma..." -ForegroundColor Cyan
& "$buildToolsPath\apksigner.bat" verify "build\aligned.apk"

Copy-Item -Force "build\aligned.apk" $outputApk
Write-Host "============================================================" -ForegroundColor Green
Write-Host " ¡APK GENERADO CON ÉXITO! " -ForegroundColor Green
Write-Host " Ubicación: $outputApk" -ForegroundColor Green
Write-Host " Tamaño: $((Get-Item $outputApk).Length / 1KB) KB" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
